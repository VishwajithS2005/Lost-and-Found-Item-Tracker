import mongoose from "mongoose";

const productSchema = new mongoose.Schema(
	{
		name: {
			type: String,
			required: true,
		},
		description: {
			type: String,
			required: true,
		},
		claimed: {
			type: Boolean,
			default: false,
			required: true,
		},
		image: {
			type: String,
			required: true,
		},
	},
	{
		timestamps: true, // createdAt and updatedAt fields
	}
);

const Product = mongoose.model("Product", productSchema);
// mongoose will create a collection named 'products' in the database
// based on the model name 'Product' (lowercase and pluralized)
export default Product;
