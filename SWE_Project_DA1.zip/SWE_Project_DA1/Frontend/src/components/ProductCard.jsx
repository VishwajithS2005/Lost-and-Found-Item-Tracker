import { Box, Button, Heading, HStack, IconButton, Image, Input, Modal, ModalBody, ModalCloseButton, ModalContent, ModalFooter, ModalHeader, ModalOverlay, Text, useColorModeValue, useDisclosure, useToast, VStack, Textarea, Menu, MenuButton, MenuList, MenuItem } from '@chakra-ui/react'
import { DeleteIcon, EditIcon } from '@chakra-ui/icons'
import React, { useState } from 'react'
import { useProductStore } from '../store/product'

const ProductCard = ({ product }) => {
    const [updatedProduct, setUpdatedProduct] = useState({
        name: product.name || '',
        description: product.description || '',
        image: product.image || '',
        claimed: product.claimed || false,
    });
    const { deleteProduct, updateProduct } = useProductStore()
    const toast = useToast()
    const { isOpen, onOpen, onClose } = useDisclosure()

    const handleUpdateProduct = async (pid, updatedProduct) => {
        const { success, message } = await updateProduct(pid, updatedProduct)
        if (!success) {
            toast({
                title: "Error",
                description: message,
                status: "error",
                duration: 5000,
                isClosable: true,
            })
        } else {
            toast({
                title: "Success",
                description: message,
                status: "success",
                duration: 5000,
                isClosable: true,
            })
            onClose();
        }
    }

    const handleDeleteProduct = async (pid) => {
        const { success, message } = await deleteProduct(pid)
        if (!success) {
            toast({
                title: "Error",
                description: message,
                status: "error",
                duration: 5000,
                isClosable: true,
            })
        }
        else {
            toast({
                title: "Success",
                description: message,
                status: "success",
                duration: 5000,
                isClosable: true,
            })
        }
    }

    const textColor = useColorModeValue("gray.600", "gray.300")
    const bg = useColorModeValue("white", "gray.800")

    return (
        <Box
            shadow='lg'
            rounded='lg'
            overflow='hidden'
            transition='all 0.3s'
            _hover={{ transform: "translateY(-5px)", shadow: "xl" }}
            bg={bg}
        >
            <Image src={product.image} alt={product.name} h={48} w={'full'} objectFit="cover" />
            <Box p={4}>
                <Heading as={'h3'} size={'md'} mb={1}>
                    {product.name}
                </Heading>
                <Text fontSize='md' color={textColor} mb={2}>
                    {product.description}
                </Text>
                <Text fontWeight='semibold' fontSize='xl' mb={4} color={textColor}>
                    Status: {product.claimed ? 'Claimed' : 'Not Claimed'}
                </Text>

                <HStack spacing={2}>
                    <IconButton
                        icon={<EditIcon />}
                        colorScheme='blue'
                        onClick={onOpen}
                    />
                    <IconButton icon={<DeleteIcon />} colorScheme='red' onClick={() => { handleDeleteProduct(product._id) }} />
                </HStack>
            </Box>

            <Modal isOpen={isOpen} onClose={onClose} isCentered>
                <ModalOverlay />
                <ModalContent>
                    <ModalHeader>Update Product</ModalHeader>
                    <ModalCloseButton />
                    <ModalBody>
                        <VStack spacing={4} align="stretch">
                            <Input
                                placeholder='Product Name'
                                name='name'
                                value={updatedProduct.name}
                                onChange={(e) => setUpdatedProduct({ ...updatedProduct, name: e.target.value })}
                            />
                            <Textarea
                                placeholder='Product Description'
                                name='description'
                                value={updatedProduct.description}
                                onChange={(e) => setUpdatedProduct({ ...updatedProduct, description: e.target.value })}
                            />
                            <Input
                                placeholder='Image URL'
                                name='image'
                                value={updatedProduct.image}
                                onChange={(e) => setUpdatedProduct({ ...updatedProduct, image: e.target.value })}
                            />
                            {updatedProduct.image && (
                                <Box boxSize="sm" mb={2} display="flex" justifyContent="center">
                                    <img src={updatedProduct.image} alt="Preview" style={{ maxHeight: 200, maxWidth: '100%', objectFit: 'contain', borderRadius: 8 }} onError={e => { e.target.style.display = 'none'; }} />
                                </Box>
                            )}
                            <Box>
                                <label style={{ fontWeight: 500, marginBottom: 4, display: 'block' }}>Status</label>
                                <Menu>
                                    <MenuButton as={Button} w="100%" textAlign="left">
                                        {updatedProduct.claimed ? 'Claimed' : 'Not Claimed'}
                                    </MenuButton>
                                    <MenuList w="100%">
                                        <MenuItem
                                            bg={!updatedProduct.claimed ? 'gray.700' : 'white'}
                                            color={!updatedProduct.claimed ? 'white' : 'black'}
                                            _hover={{ bg: 'gray.700', color: 'white' }}
                                            onClick={() => setUpdatedProduct({ ...updatedProduct, claimed: false })}
                                        >
                                            Not Claimed
                                        </MenuItem>
                                        <MenuItem
                                            bg={updatedProduct.claimed ? 'gray.700' : 'white'}
                                            color={updatedProduct.claimed ? 'white' : 'black'}
                                            _hover={{ bg: 'gray.700', color: 'white' }}
                                            onClick={() => setUpdatedProduct({ ...updatedProduct, claimed: true })}
                                        >
                                            Claimed
                                        </MenuItem>
                                    </MenuList>
                                </Menu>
                            </Box>
                        </VStack>
                    </ModalBody>
                    <ModalFooter>
                        <Button
                            colorScheme='blue'
                            mr={3}
                            onClick={() => handleUpdateProduct(product._id, updatedProduct)}
                        >
                            Update
                        </Button>
                        <Button variant='ghost' onClick={onClose}>
                            Cancel
                        </Button>
                    </ModalFooter>
                </ModalContent>
            </Modal>
        </Box>
    )
}

export default ProductCard