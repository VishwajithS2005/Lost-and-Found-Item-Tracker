
import React, { useState } from 'react';
import axios from 'axios';
import {
    Box,
    Button,
    Container,
    FormControl,
    FormLabel,
    Heading,
    Input,
    Textarea,
    VStack,
    Alert,
    AlertIcon,
    useColorModeValue,
    Menu,
    MenuButton,
    MenuList,
    MenuItem,
} from '@chakra-ui/react';

const CreatePage = () => {
    const [name, setName] = useState('');
    const [description, setDescription] = useState('');
    const [image, setImage] = useState('');
    const [claimed, setClaimed] = useState(false);
    const [loading, setLoading] = useState(false);
    const [error, setError] = useState('');
    const [success, setSuccess] = useState(false);

    const handleSubmit = async (e) => {
        e.preventDefault();
        setLoading(true);
        setError('');
        setSuccess(false);
        try {
            await axios.post('http://localhost:5000/api/products', {
                name,
                description,
                image,
                claimed,
            });
            setSuccess(true);
            setName('');
            setDescription('');
            setImage('');
            setClaimed(false);
        } catch (err) {
            setError(err.response?.data?.message || 'Something went wrong');
        } finally {
            setLoading(false);
        }
    };

    return (
        <Container maxW="md" mt={10} p={0}>
            <Box
                bg={useColorModeValue('white', 'gray.700')}
                p={8}
                borderRadius="lg"
                boxShadow="md"
            >
                <Heading as="h2" size="lg" mb={6} textAlign="center">
                    Create Product
                </Heading>
                <form onSubmit={handleSubmit}>
                    <VStack spacing={4} align="stretch">
                        <FormControl isRequired>
                            <FormLabel>Name</FormLabel>
                            <Input
                                type="text"
                                value={name}
                                onChange={e => setName(e.target.value)}
                                placeholder="Enter product name"
                            />
                        </FormControl>
                        <FormControl isRequired>
                            <FormLabel>Description</FormLabel>
                            <Textarea
                                value={description}
                                onChange={e => setDescription(e.target.value)}
                                placeholder="Enter product description"
                            />
                        </FormControl>
                        <FormControl isRequired>
                            <FormLabel>Image URL</FormLabel>
                            <Input
                                type="url"
                                value={image}
                                onChange={e => setImage(e.target.value)}
                                placeholder="Enter image URL"
                            />
                        </FormControl>
                        {image && (
                            <Box boxSize="sm" mb={2} display="flex" justifyContent="center">
                                <img src={image} alt="Preview" style={{ maxHeight: 200, maxWidth: '100%', objectFit: 'contain', borderRadius: 8 }} onError={e => { e.target.style.display = 'none'; }} />
                            </Box>
                        )}
                        <FormControl isRequired>
                            <FormLabel>Status</FormLabel>
                            <Box>
                                <Menu>
                                    <MenuButton as={Button} w="100%" textAlign="left">
                                        {claimed ? 'Claimed' : 'Not Claimed'}
                                    </MenuButton>
                                    <MenuList w="100%">
                                        <MenuItem
                                            bg={!claimed ? 'gray.700' : 'white'}
                                            color={!claimed ? 'white' : 'black'}
                                            _hover={{ bg: 'gray.700', color: 'white' }}
                                            onClick={() => setClaimed(false)}
                                        >
                                            Not Claimed
                                        </MenuItem>
                                        <MenuItem
                                            bg={claimed ? 'gray.700' : 'white'}
                                            color={claimed ? 'white' : 'black'}
                                            _hover={{ bg: 'gray.700', color: 'white' }}
                                            onClick={() => setClaimed(true)}
                                        >
                                            Claimed
                                        </MenuItem>
                                    </MenuList>
                                </Menu>
                            </Box>
                        </FormControl>
                        <Button
                            type="submit"
                            colorScheme="blue"
                            isLoading={loading}
                            w="full"
                        >
                            Create
                        </Button>
                        {error && (
                            <Alert status="error">
                                <AlertIcon />
                                {error}
                            </Alert>
                        )}
                        {success && (
                            <Alert status="success">
                                <AlertIcon />
                                Product created successfully!
                            </Alert>
                        )}
                    </VStack>
                </form>
            </Box>
        </Container>
    );
};

export default CreatePage;