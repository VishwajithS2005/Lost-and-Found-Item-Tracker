import { create } from "zustand";

export const useProductStore = create((set) => ({
	products: [],
	setProducts: (products) => set({ products }),
    createProduct: async (newProduct) => {
        if(!newProduct.name || !newProduct.description || !newProduct.image || typeof newProduct.claimed !== 'boolean') {
            return {success: false, message: "All fields are required, including claimed"}; 
        }
        const res = await fetch("/api/products", {
            method: "POST",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify({
                name: newProduct.name,
                description: newProduct.description,
                image: newProduct.image,
                claimed: newProduct.claimed
            }),
        })
        const data = await res.json();
        if (!data.success) {
            return {success: false, message: data.message};
        }
        set((state) => ({
            products: [...state.products, data.data],
        }))
        return {success: true, message: "Product created successfully"};
    },
    fetchProducts: async () => {
        try {
            const res = await fetch("/api/products", {
                method: "GET",
                headers: {
                    "Content-Type": "application/json",
                },
            });
            const data = await res.json();
            if (data && data.success && Array.isArray(data.data)) {
                set({ products: data.data });
            } else {
                set({ products: [] });
            }
        } catch (err) {
            set({ products: [] });
        }
    },
    deleteProduct: async (pid) => {
        const res = await fetch(`/api/products/${pid}`, {
            method: "DELETE",
            headers: {
                "Content-Type": "application/json",
            },
        })
        const data = await res.json();
        if(!data.success) {
            return {success: false, message: data.message};
        }
        //Updates the UI immediately without needing to refresh
        set((state) => ({
            products: state.products.filter((product) => product._id !== pid),
        }))
        return {success: true, message: data.message};
    },
    updateProduct: async (pid, updatedProduct) => {
        const res = await fetch(`/api/products/${pid}`, {
            method: "PUT",
            headers: {
                "Content-Type": "application/json",
            },
            body: JSON.stringify(updatedProduct),
        })
        const data = await res.json();
        if(!data.success) {
            return {success: false, message: data.message};
        }
        //Updates the UI immediately without needing to refresh
        set((state) => ({
            products: state.products.map((product) => product._id === pid ? data.data : product),
        }))
        return {success: true, message: data.message};
    },
}));
